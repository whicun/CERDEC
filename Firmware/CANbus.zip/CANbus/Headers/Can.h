/*
 * Can.h
 *
 *  Created on: Nov 14, 2019
 *      Author: AntonS
 */

#ifndef HEADERS_CAN_H_
#define HEADERS_CAN_H_

void configCAN();

#endif /* HEADERS_CAN_H_ */
