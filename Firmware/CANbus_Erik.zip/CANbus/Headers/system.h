#ifndef PRO_D_SYSTEM_HEADER
#define PRO_D_SYSTEM_HEADER

// system init
void sys_init();

void xintf_init();

void flash_init();

#endif
