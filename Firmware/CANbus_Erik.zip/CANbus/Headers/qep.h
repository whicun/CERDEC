#ifndef QEP_H
#define QEP_H

void qep_init( void );

int qep_getCountA( void );
void qep_rstCountA( void );
int qep_getCountB( void );
void qep_rstCountB( void );

#endif
