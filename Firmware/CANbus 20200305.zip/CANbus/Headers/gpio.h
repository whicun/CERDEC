#ifndef PRO_D_GPIO_HEADER
#define PRO_D_GPIO_HEADER

void gpio_init();

#endif
