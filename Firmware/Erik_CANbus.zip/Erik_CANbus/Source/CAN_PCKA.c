/*
 * CAN_PCKA.c
 *
 *  Created on: Dec 3, 2019
 *      Author: AntonS
 */

#include "CAN_PCKA.h"

struct BMSSTATUS	bms_status;
union BMS_CMD_REG	bms_cmd;
